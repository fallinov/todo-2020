<template>
  <q-page padding>
    <h1>Paramètres</h1>
  </q-page>
</template>

<script>
export default {
}
</script>
