<template>
  <q-page padding>
    <q-list bordered separator>
      <tache
        v-for="tache in taches"
        :key="tache.id"
        :tache="tache"
      />
    </q-list>
  </q-page>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'PageTaches',
  computed: {
    ...mapGetters('taches', ['taches'])
  },
  components: {
    tache: require('components/Taches/Tache').default
  }
}
</script>

<style lang="scss">

  .text-barre {
    text-decoration: line-through;
  }

</style>
